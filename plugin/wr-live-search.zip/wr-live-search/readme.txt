== WR Live Search ==
WR Live Search is a WordPress plugin developed by WooRockets. It help you create a search box that will display search results instantly with rich content like thumbnail images, prices, title, description... You can also choose to search from WooCommerce products or blog content.

== Changelog ==
1.0.7
- Fixed bug can't change the product thumbnail size

1.0.7
- Make setting to control the product thumbnail size of the Live Search.

1.0.6
- Fix bugs compatible with WC 3.0

1.0.5
- Fix bug broken style of search box on IE11

1.0.4
- Improve search function to search phrase.

1.0.3
- Fix bug search result page does not working

1.0.2
- Add feature to search in Product SKU
- Update search filter in search page

1.0.1
- Added language file.
